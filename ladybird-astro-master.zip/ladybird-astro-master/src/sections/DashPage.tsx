import FakeDashboard from "./FakeDashboard.astro";

const DashPage = () => {
	return (
		<div>
			<FakeDashboard />
		</div>
	);
};

export default DashPage;
